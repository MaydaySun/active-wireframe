<?php use Pimcore\Model\Asset; ?>
<style>
    @media screen, print {
        section#page {
            padding: 0 !important;
        }

        #w2p-img img {
            width: 100%;
            height: 100%;
        }
    }
</style>

<div id="w2p-img" class="w2p-area">
    <div class="w2p-img-container">
        <?php if ($this->editmode) { ?>
            <?= $this->image("w2p-image", array(
                    "hidetext" => true,
                    "thumbnail" => $this->thumbnail)
            ); ?>
        <?php } else { ?>
            <?php $asset = Asset::getById($this->image("w2p-image")->getId()); ?>
            <?php if ($asset instanceof Asset\Image) { ?>
                <img src="<?= $this->baseUrl . $asset->getThumbnail($this->thumbnail) ?>"/>
            <?php } ?>

        <?php } ?>

    </div>
</div>
