<?php use Pimcore\Model\Asset; ?>
<style>
    #w2p-area-img,
    #w2p-area-img > .pimcore_editable.pimcore_tag_image,
    #w2p-area-img img {
        height: 100%;
        width: 100%;
    }
</style>

<div id="w2p-area-img" class="w2p-area">
    <?php if ($this->editmode) { ?>

        <?= $this->image("w2p-image", array(
                "hidetext" => true,
                "thumbnail" => $this->thumbnail)
        ); ?>

    <?php } else { ?>

        <?php $asset = Asset::getById($this->image("w2p-image")->getId()); ?>
        <?php if ($asset instanceof Asset\Image) { ?>
            <img src="<?= $this->baseUrl . $asset->getThumbnail($this->thumbnail) ?>"/>
        <?php } ?>

    <?php } ?>
</div>
