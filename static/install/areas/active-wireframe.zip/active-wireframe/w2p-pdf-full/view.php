<?php use Pimcore\Model\Asset; ?>
<style>
    @media screen, print {
        section#page {
            padding: 0 !important;
        }

        #activeWireframe .box-w2p-full {
            width: <?= $this->pageWidthLandmark ?> !important;
            height: <?= $this->pageHeightLandmark ?> !important;
            position: absolute;
        }

        #w2p-full-pdf .pimcore_tag_pdf,
        #w2p-full-pdf .pimcore_tag_image_empty,
        #w2p-full-pdf .pimcore_tag_pdf .x-panel,
        #w2p-full-pdf .pimcore_tag_pdf .x-panel-body {
            width: <?= $this->pageWidthLandmark ?> !important;
            height: <?= $this->pageHeightLandmark ?> !important;
        }

        #w2p-full-pdf img {
            width: 100%;
            height: 100%;
        }
    }
</style>

<div id="w2p-full-pdf" class="w2p-area">
    <div>
        <?php if ($this->editmode) { ?>

            <?= $this->pdf("w2p-pdf-full", array(
                "hidetext" => true,
                "thumbnail" => $this->thumbnail)); ?>

        <?php } else { ?>

            <?php $asset = Asset::getById($this->pdf("w2p-pdf-full")->getId()); ?>
            <?php if ($asset instanceof Asset\Document) { ?>
                <img src="<?= $this->baseUrl . $asset->getImageThumbnail($this->thumbnail) ?>"/>
            <?php } ?>

        <?php } ?>
    </div>
</div>

<script>
    var parentW2p = getParentByClass(document.getElementById('w2p-full-pdf'), 'box-w2p');
    parentW2p.classList.remove("box-w2p");
    parentW2p.classList.add('box-w2p-full');
</script>