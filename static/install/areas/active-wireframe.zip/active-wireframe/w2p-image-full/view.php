<?php use Pimcore\Model\Asset; ?>
<style>
    #page {padding: 0 !important;}
    .numpage {display: none}

    #activeWireframe .box-w2p-full {
        width: <?= $this->pageWidthLandmark ?> !important;
        height: <?= $this->pageHeightLandmark ?> !important;
        position: absolute;
    }

    #w2p-full-img .pimcore_tag_image,
    #w2p-full-img .pimcore_tag_image_empty,
    #w2p-full-img .pimcore_tag_image .x-panel,
    #w2p-full-img .pimcore_tag_image .x-panel-body {
        width: <?= $this->pageWidthLandmark ?> !important;
        height: <?= $this->pageHeightLandmark ?> !important;
    }

    #w2p-full-img img {
        width: 100%;
        height: 100%;
    }
</style>

<div id="w2p-full-img" class="w2p-area">
    <?php if ($this->editmode) { ?>

        <?= $this->image("w2p-image-full", array(
            "hidetext" => true,
            "thumbnail" => $this->thumbnail
        )); ?>

    <?php } else { ?>

        <?php $asset = Asset::getById($this->image("w2p-image-full")->getId()); ?>
        <?php if ($asset instanceof Asset\Image) { ?>
            <img src="<?= $this->baseUrl . $asset->getThumbnail($this->thumbnail) ?>"/>
        <?php } ?>

    <?php } ?>
</div>

<script>
    var parentW2p = getParentByClass(document.getElementById('w2p-full-img'), 'box-w2p');
    parentW2p.classList.remove("box-w2p");
    parentW2p.classList.add('box-w2p-full');
</script>
