<div id="w2p-wysiwyg" class="w2p-area">
    <div><?= $this->wysiwyg("w2p-wywiwyg"); ?></div>
</div>