<style>
    #w2p-area-wysiwyg,
    #w2p-area-wysiwyg > .pimcore_editable.pimcore_tag_wysiwyg,
    #w2p-area-wysiwyg > .pimcore_editable.pimcore_tag_wysiwyg > .pimcore_wysiwyg{
        height: 100%;
    }
</style>

<div id="w2p-area-wysiwyg" class="w2p-area">
    <?= $this->wysiwyg("w2p-wywiwyg"); ?>
</div>