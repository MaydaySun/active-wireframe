<?php use Pimcore\Model\Asset; ?>
<style>
    @media screen, print {
        section#page {
            padding: 0 !important;
        }

        #w2p-pdf img {
            width: 100%;
            height: 100%;
        }
    }
</style>

<div id="w2p-pdf" class="w2p-area">
    <div>
        <?php if ($this->editmode) { ?>
            <?= $this->pdf("w2p-pdf", array(
                    "hidetext" => true,
                    "thumbnail" => $this->thumbnail)
            ); ?>
        <?php } else { ?>
            <?php $asset = Asset::getById($this->pdf("w2p-pdf")->getId()); ?>
            <?php if ($asset instanceof Asset\Document) { ?>
                <img src="<?= $this->baseUrl . $asset->getImageThumbnail($this->thumbnail) ?>"/>
            <?php } ?>
        <?php } ?>
    </div>
</div>