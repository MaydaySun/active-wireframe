<?php use Pimcore\Model\Asset; ?>
<style>
    #w2p-area-pdf,
    #w2p-area-pdf > .pimcore_editable.pimcore_tag_pdf,
    #w2p-area-pdf img {
        height: 100%;
        width: 100%;
    }
</style>

<div id="w2p-area-pdf" class="w2p-area">
    <?php if ($this->editmode) { ?>

        <?= $this->pdf("w2p-pdf", array(
                "hidetext" => true,
                "thumbnail" => $this->thumbnail)
        ); ?>

    <?php } else { ?>

        <?php $asset = Asset::getById($this->pdf("w2p-pdf")->getId()); ?>
        <?php if ($asset instanceof Asset\Document) { ?>
            <img src="<?= $this->baseUrl . $asset->getImageThumbnail($this->thumbnail) ?>"/>
        <?php } ?>

    <?php } ?>
</div>