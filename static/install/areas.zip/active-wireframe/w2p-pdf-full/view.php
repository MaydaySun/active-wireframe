<style>
    #activeWireframe #w2p-full-pdf .pimcore_tag_pdf,
    #activeWireframe #w2p-full-pdf .pimcore_tag_image_empty,
    #activeWireframe #w2p-full-pdf .pimcore_tag_pdf .x-panel,
    #activeWireframe #w2p-full-pdf .pimcore_tag_pdf .x-panel-body {
        width: <?= $this->pageWidthLandmark ?> !important;
        height: <?= $this->pageHeightLandmark ?> !important;
    }
    #activeWireframe #w2p-full-pdf img {
        width: 100%;
        height: 100%;
    }
    #activeWireframe #number-page {
        display: none;
    }
</style>
<div id="w2p-full-pdf" class="w2p-full">
    <?php if ($this->editmode) { ?>
        <?= $this->pdf("w2p-pdf-full", ["hidetext" => true, "thumbnail" => $this->thumbnail]); ?>
    <?php } else { ?>
        <?php $asset = \Pimcore\Model\Asset::getById($this->pdf("w2p-pdf-full")->getId()); ?>
        <?php if ($asset instanceof \Pimcore\Model\Asset\Document) { ?>
            <img src="<?= $this->baseUrl . $asset->getImageThumbnail($this->thumbnail) ?>"/>
        <?php } ?>
    <?php } ?>
</div>