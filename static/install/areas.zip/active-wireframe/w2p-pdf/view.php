<style>
    #activeWireframe #w2p-area-pdf,
    #activeWireframe #w2p-area-pdf > .pimcore_editable.pimcore_tag_pdf,
    #activeWireframe #w2p-area-pdf img {
        height: 100%;
        width: 100%;
    }
</style>
<div id="w2p-area-pdf" class="w2p-area">
    <?php if ($this->editmode) { ?>
        <?= $this->pdf("w2p-pdf", ["hidetext" => true, "thumbnail" => $this->thumbnail]); ?>
    <?php } else { ?>
        <?php $asset = Pimcore\Model\Asset::getById($this->pdf("w2p-pdf")->getId()); ?>
        <?php if ($asset instanceof Pimcore\Model\Asset\Document) { ?>
            <img src="<?= $this->baseUrl . $asset->getImageThumbnail($this->thumbnail) ?>"/>
        <?php } ?>
    <?php } ?>
</div>