<style>
    #activeWireframe #w2p-area-img,
    #activeWireframe #w2p-area-img > .pimcore_editable.pimcore_tag_image,
    #activeWireframe #w2p-area-img img {
        height: 100%;
        width: 100%;
    }
</style>
<div id="w2p-area-img" class="w2p-area">
    <?php if ($this->editmode) { ?>
        <?= $this->image("w2p-image", ["hidetext" => true, "thumbnail" => $this->thumbnail]); ?>
    <?php } else { ?>
        <?php $asset = Pimcore\Model\Asset::getById($this->image("w2p-image")->getId()); ?>
        <?php if ($asset instanceof Pimcore\Model\Asset\Image) { ?>
            <img src="<?= $this->baseUrl . $asset->getThumbnail($this->thumbnail) ?>"/>
        <?php } ?>
    <?php } ?>
</div>
