<style>
    #activeWireframe #w2p-full-img .pimcore_tag_image,
    #activeWireframe #w2p-full-img .pimcore_tag_image_empty,
    #activeWireframe #w2p-full-img .pimcore_tag_image .x-panel,
    #activeWireframe #w2p-full-img .pimcore_tag_image .x-panel-body {
        width: <?= $this->pageWidthLandmark ?> !important;
        height: <?= $this->pageHeightLandmark ?> !important;
    }
    #activeWireframe #w2p-full-pdf img {
        width: 100%;
        height: 100%;
    }
    #activeWireframe #number-page {
        display: none;
    }
</style>
<div id="w2p-full-img" class="w2p-full">
    <?php if ($this->editmode) { ?>
        <?= $this->image("w2p-image-full", ["hidetext" => true, "thumbnail" => $this->thumbnail]); ?>
    <?php } else { ?>
        <?php $asset = Pimcore\Model\Asset::getById($this->image("w2p-image-full")->getId()); ?>
        <?php if ($asset instanceof Pimcore\Model\Asset\Image) { ?>
            <img src="<?= $this->baseUrl . $asset->getThumbnail($this->thumbnail) ?>"/>
        <?php } ?>
    <?php } ?>
</div>
